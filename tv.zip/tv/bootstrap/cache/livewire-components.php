<?php return array (
  'user-status' => 'App\\Http\\Livewire\\UserStatus',
);