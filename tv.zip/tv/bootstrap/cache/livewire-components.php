<?php return array (
  'count-toggle' => 'App\\Http\\Livewire\\CountToggle',
  'toggle-button' => 'App\\Http\\Livewire\\ToggleButton',
  'toggle-event' => 'App\\Http\\Livewire\\ToggleEvent',
  'user-status' => 'App\\Http\\Livewire\\UserStatus',
);