<div>
    {{-- The Master doesn't talk, he acts. --}}
    <div class="form-check form-switch">
  <input class="form-check-input"  wire:model="isActive" type="checkbox" role="switch" @if($isActive) checked @endif>
</div>
</div>
