
<div class="form-check form-switch" >
  
  <input type="checkbox" class="form-check-input"  wire:model.lazy="hasStock"   role="switch" @if($hasStock) checked @endif>
</div>

