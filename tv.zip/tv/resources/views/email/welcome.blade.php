<x-mail::message>
# Welcome to Teen Africa TV Community

Thank you for registering to our community 
<p>Expect great things</p>

<x-mail::button :url="''">
Visit Site 

</x-mail::button>

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
