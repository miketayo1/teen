<div wire:poll>
        <?php if($hasCount == 0): ?>
                <p class="mb-0 text-sm" wire:model.lazy="hasCount" >Active: <?php echo e($hasCount="off"); ?></p>
        <?php else: ?>
                <p class="mb-0 text-sm" wire:model.lazy="hasCount" >Active: <?php echo e($hasCount="on"); ?> </p>
        <?php endif; ?>
        
</div>
<?php /**PATH F:\xampp\htdocs\teen\tv\resources\views/livewire/count-toggle.blade.php ENDPATH**/ ?>