
<div class="form-check form-switch" >
  
  <input type="checkbox" class="form-check-input"  wire:model.lazy="hasStock"   role="switch" <?php if($hasStock): ?> checked <?php endif; ?>>
</div>

<?php /**PATH F:\xampp\htdocs\teen\tv\resources\views/livewire/toggle-button.blade.php ENDPATH**/ ?>