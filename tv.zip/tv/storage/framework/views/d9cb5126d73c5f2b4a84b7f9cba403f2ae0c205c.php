<div>
    
    <div class="form-check form-switch">
  <input class="form-check-input"  wire:model="isActive" type="checkbox" role="switch" <?php if($isActive): ?> checked <?php endif; ?>>
</div>
</div>
<?php /**PATH F:\xampp\htdocs\teen\tv\resources\views/livewire/user-status.blade.php ENDPATH**/ ?>