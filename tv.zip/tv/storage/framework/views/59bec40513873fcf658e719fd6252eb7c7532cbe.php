<footer class="footer position-absolute bottom-footer py-2 w-100 z-index-1">
    <div class="container">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-12 col-md-6 my-auto">
                <div class="copyright text-center text-sm text-white text-lg-start">
                    © <script>
                        document.write(new Date().getFullYear())

                    </script>,
                    made with <i class="fa fa-heart" aria-hidden="true"></i> by
                    <a href="#" class="font-weight-bold text-white" target="_blank">MIC
                        TECHS</a> 
                </div>
            </div>
            <div class="col-12 col-md-6">
                <ul class="nav nav-footer justify-content-center justify-content-lg-end">
                    
                </ul>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH F:\xampp\htdocs\teen\tv\resources\views/components/footers/guest.blade.php ENDPATH**/ ?>